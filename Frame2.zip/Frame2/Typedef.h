#pragma once

#ifndef __TYPEDEF_H__

class CGameObject;
typedef list<CGameObject*>	OBJECT_LIST;

#define __TYPEDEF_H__
#endif
