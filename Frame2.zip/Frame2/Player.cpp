#include "stdafx.h"
#include "Player.h"

#include "AfterImage.h"

CPlayer::CPlayer()
	: m_bIsJump(false),
	m_bDJump(false),
	m_fJumpForce(0.f),
	m_fJumpAcc(0.f),
	m_ePreState(STATE_END),
	m_eCurState(STATE_END)
{
	ZeroMemory(&m_tFrame, sizeof(FRAME));
}


CPlayer::~CPlayer()
{
}
//TODO: ���� ���� �����̴°� ,�Ʒ�������  ������ �����ؾ���
void CPlayer::Initialize()
{
	m_tInfo.fX = 400.f;
	m_tInfo.fY = 300.f;
	m_tInfo.fCX = 50.f;
	m_tInfo.fCY = 50.f;
	m_fAtkRange = 106.0;
	m_fSpeed = 5.f;
	m_fAngle = 90.f;	// Degree	
	m_iCount = 0;
	m_fJumpForce = 25.0f;
	m_fAtkPower = 20;
	m_flatY = m_tInfo.fY;
	m_bDown = false;

	m_eCurState = STATE_IDLE;
	m_ePreState = m_eCurState;
	m_bIsDead = false;
	m_tFrame.dwFrameStart = 0;
	m_tFrame.dwFrameCount = 4;
	m_tFrame.dwFrameX = 0;
	m_tFrame.dwFrameY = 0;
	m_tFrame.dwFrameSpeed = 200; // 0.2�� ����
	m_tFrame.dwOldTime = GetTickCount();
	m_bDJump = false;
	m_bIsAttk = false;
	m_WallJump = false;
	m_wstrImageKey = L"Player_R";
	
	m_wstrImageKey2 = L"Slash";
	m_tAtkFrame.dwFrameCount = 5;
	m_tAtkFrame.dwFrameStart = 0;
	m_tAtkFrame.dwFrameX = 106;
	m_tAtkFrame.dwFrameY = 0;
	m_tAtkFrame.dwFrameSpeed = 50;
	m_tAtkFrame.dwOldTime = GetTickCount();
	CObjectManager::GetInstance()->AddObject(AFTERIMAGE, CObjFactory<CAfterImage>::CreateObject(m_WorldPos.x,m_WorldPos.y));

	//UI�κ�
	m_iAlpha = 0;
	m_BlendFuntion.AlphaFormat = 0;
	m_BlendFuntion.BlendOp = AC_SRC_OVER;
	m_BlendFuntion.BlendFlags = 0;
	m_BlendFuntion.SourceConstantAlpha = m_iAlpha;
	CBmpManager::GetInstance()->LoadBmp(L"BulletTime", L"../Image/BackGround/BulletTime.bmp");
	CBmpManager::GetInstance()->LoadBmp(L"HUDTimer", L"../Image/UI/HUD_Timer.bmp");//112x19
	CBmpManager::GetInstance()->LoadBmp(L"TimerGage", L"../Image/UI/TimerGage.bmp");//94x11
	CBmpManager::GetInstance()->LoadBmp(L"HUDUI", L"../Image/UI/HUD_UI.bmp");//640x23
	CBmpManager::GetInstance()->LoadBmp(L"BatteryGage", L"../Image/UI/BatteryRedGage.bmp");//77x19
	CBmpManager::GetInstance()->LoadBmp(L"Battery", L"../Image/UI/BatteryBlueGage.bmp");//54x10
	CBmpManager::GetInstance()->LoadBmp(L"BulletReflect", L"../Image/Player/BulletReflect.bmp");
	m_fGameTimer = 0.f;
	m_fBulletGage = 100.f;
}

int CPlayer::Update()
{
	m_fGameTimer += 2.0f/g_fTime;
	

	KeyInput();
	UpdateWorldPos2();
	Move();
	Jump();
	WallJump();
	if (GetIsAttk())
	{
		m_eCurState = STATE_ATTACK;
		m_iCount++;
		//cout << m_iCount<<"Y=��" << sinf(m_fRadian)*m_fAtkPower << endl;
		m_tInfo.fX += cosf(m_fRadian)*m_fAtkPower*0.5;
		m_tInfo.fY -= sinf(m_fRadian)*m_fAtkPower*0.5;
		//m_WorldPos.x += cosf(m_fRadian)*m_fAtkPower*0.5;
		//m_WorldPos.y -= sinf(m_fRadian)*m_fAtkPower;
		m_bDJump = false;
		m_WallJump = false;
		if (m_iCount % 10==0)
		{
			m_iCount = 0;
			m_bIsAttk = false;
			m_eCurState = STATE_IDLE;
			
		}

		//cout << "��= " << m_fAngle << endl;
	}
	Attack();
	ScrollOffset();
	ChangeState();
	Animate();
	return NO_EVENT;
}

void CPlayer::Render(HDC hdc)
{


	CGameObject::UpdateRect2();
	BulletTime(hdc);
	RenderUI(hdc);
	HDC hMemDC = CBmpManager::GetInstance()->GetMemDC(m_wstrImageKey);
	NULL_CHECK(hMemDC);
	//Source DC�� �׷��� ��Ʈ���� Dest DC�� �����ϴ� �Լ�.�� �� ������ ������ ������ �� �ִ�.
	if (CKeyManager::GetInstance()->KeyPressing(KEY_O))
	{
		Rectangle(hdc, m_tRect.left, m_tRect.top, m_tRect.right, m_tRect.bottom);
		Rectangle(hdc, m_tHitBox.left, m_tHitBox.top, m_tHitBox.right, m_tHitBox.bottom);
	}
	GdiTransparentBlt(hdc,m_tRect.left- m_tInfo.fCX*0.5,m_tRect.top- m_tInfo.fCY*0.5,(int)m_tInfo.fCX*2,
		(int)m_tInfo.fCY*2,	hMemDC,m_tFrame.dwFrameX*m_tFrame.dwFrameStart,m_tFrame.dwFrameY,m_tInfo.fCX,m_tInfo.fCY,RGB(0, 0, 0));

		hMemDC = CBmpManager::GetInstance()->GetMemDC(m_wstrImageKey2);
		GdiTransparentBlt(hdc,m_WorldPos.x-106,m_WorldPos.y - 106,212,212,hMemDC,m_tAtkFrame.dwFrameX*m_tAtkFrame.dwFrameStart,
			m_tAtkFrame.dwFrameY,106,106,RGB(0, 0, 0));
	


	MoveToEx(hdc, m_WorldPos.x, m_WorldPos.y	, nullptr);
	if (m_bIsAttk)
	{
		LineTo(hdc, g_tMouseInfo.ptStart.x, g_tMouseInfo.ptStart.y);
	}

}

void CPlayer::Release()
{
}

void CPlayer::KeyInput()
{
	if (CKeyManager::GetInstance()->KeyPressing(KEY_SHIFT))
	{
		//if (g_fTime > 0.2)
		//{
		//	g_fTime -=0.05;
		//	cout << g_fTime << endl;
		//}
		g_fTime = 0.2;
	}
	else
	{
		g_fTime = 1;
	}
	if (CKeyManager::GetInstance()->KeyDown(KEY_SPACE))
	{
		m_bIsJump = true;
		if(m_bDJump)
			m_WallJump = true;
		
		if (!m_bIsAttk)
			m_eCurState = STATE_JUMP;

	}
	if (CKeyManager::GetInstance()->KeyUp(KEY_SPACE))
	{
		m_bIsJump = false;
	}
	else
		m_eCurState = STATE_IDLE;

	if (CKeyManager::GetInstance()->KeyPressing(KEY_A))
	{
		m_wstrImageKey = L"Player_L";
		if (!m_bDJump)
		{
			m_tInfo.fX -= m_fSpeed;
			if (!m_bIsJump)
				m_eCurState = STATE_RUN;
		}
		else
			m_eCurState = STATE_WALLGRIP;
	}
	else if (CKeyManager::GetInstance()->KeyUp(KEY_A)||CKeyManager::GetInstance()->KeyUp(KEY_D))
	{
		m_bDJump = false;
		m_WallJump = false;
	}
	if (CKeyManager::GetInstance()->KeyPressing(KEY_D))
	{
		m_wstrImageKey = L"Player_R";
		if (!m_bDJump)
		{
			m_tInfo.fX += m_fSpeed;
			if (!m_bIsJump)
				m_eCurState = STATE_RUN;
		}
		else
			m_eCurState = STATE_WALLGRIP;
	}

	if (CKeyManager::GetInstance()->KeyUp(KEY_A)|| CKeyManager::GetInstance()->KeyUp(KEY_D))
	{
		m_bDJump = false;
		m_WallJump = false;
	}

	else if (CKeyManager::GetInstance()->KeyPressing(KEY_W))
	{
		m_tInfo.fY -= m_fSpeed;
		m_eCurState = STATE_RUN;
	}
	if (CKeyManager::GetInstance()->KeyPressing(KEY_S))//�ٿ�
	{
		if (m_bOnFlat)
			Roll();
		else
			m_bDown=true;
		
	}
	if (CKeyManager::GetInstance()->KeyDown(KEY_LBUTTON))//����
	{
		//cout << m_WorldPos.x << endl;
		if (m_WorldPos.x > g_tMouseInfo.ptStart.x)
			m_wstrImageKey = L"Player_L";
		if (m_WorldPos.x <= g_tMouseInfo.ptStart.x)
			m_wstrImageKey = L"Player_R";
		
		SetAngle(g_tMouseInfo.ptStart.x, g_tMouseInfo.ptStart.y);
		m_bIsAttk = true;
		g_tMouseInfo.bStart = true;

	}
	if (CKeyManager::GetInstance()->KeyUp(KEY_S))//
		m_bDown = false;

	if (CKeyManager::GetInstance()->KeyUp(KEY_LBUTTON))//
		g_tMouseInfo.bStart = false;
}


void CPlayer::Attack()
{


	float fratio = 0.125f;
	if (GetIsAttk())
	{
		if (m_fAngle >= -22.5 && m_fAngle < 22.5)
			m_tHitBox = { (LONG)(m_WorldPos.x),(LONG)(m_WorldPos.y - m_fAtkRange*fratio),(LONG)(m_WorldPos.x + m_fAtkRange), (LONG)(m_WorldPos.y + m_fAtkRange*fratio) };
		else if (m_fAngle >= 22.5 && m_fAngle < 67.5)
			m_tHitBox = { (LONG)(m_WorldPos.x),(LONG)(m_WorldPos.y - m_fAtkRange*0.75), (LONG)(m_WorldPos.x + m_fAtkRange*0.75), (LONG)(m_WorldPos.y) };
		else if (m_fAngle >= 67.5 && m_fAngle < 112.5)
			m_tHitBox = { (LONG)(m_WorldPos.x - m_fAtkRange*fratio),(LONG)(m_WorldPos.y - m_fAtkRange), (LONG)(m_WorldPos.x + m_fAtkRange*fratio),(LONG)(m_WorldPos.y) };
		else if (m_fAngle >= 112.5 && m_fAngle < 157.5)
			m_tHitBox = { (LONG)(m_WorldPos.x - m_fAtkRange*0.75), (LONG)(m_WorldPos.y - m_fAtkRange*0.75),(LONG)(m_WorldPos.x), (LONG)m_WorldPos.y };
		else if (m_fAngle >= 157.5 || m_fAngle < -157.5)
			m_tHitBox = { (LONG)(m_WorldPos.x - m_fAtkRange), (LONG)(m_WorldPos.y - m_fAtkRange*fratio), (LONG)(m_WorldPos.x), (LONG)(m_WorldPos.y + m_fAtkRange*fratio) };
		else if (m_fAngle <= -112.5 && m_fAngle > -157.5)
			m_tHitBox = { (LONG)(m_WorldPos.x - m_fAtkRange*0.75), (LONG)(m_tInfo.fY),(LONG)(m_WorldPos.x),(LONG)(m_tInfo.fY + m_fAtkRange*0.75) };
		else if (m_fAngle <= -67.5 && m_fAngle > -112.5)
			m_tHitBox = { (LONG)(m_WorldPos.x - m_fAtkRange*fratio), (LONG)(m_WorldPos.y), (LONG)(m_WorldPos.x + m_fAtkRange*fratio),(LONG)(m_WorldPos.y + m_fAtkRange) };
		else if (m_fAngle <= -22.5 && m_fAngle > -67.5)
			m_tHitBox = { (LONG)(m_WorldPos.x), (LONG)(m_WorldPos.y), (LONG)(m_WorldPos.x + m_fAtkRange*0.75), (LONG)(m_WorldPos.y + m_fAtkRange*0.75) };
	}
	else
	{
		m_tHitBox = { 0,0,0,0 };
	}

}

void CPlayer::Move()
{

	//cout << "����" << m_fLeftVal << "    " << m_fRightVal << endl;
	if (!m_bDJump)
	{
		if (!m_bIsColl && !m_bIsJump)
		{
			if (m_fRightVal < 9)
			{
				m_fRightVal = m_fJumpForce*m_fJumpAcc*m_fJumpAcc*0.5;
				m_fJumpAcc += 0.15;

			}
			else
				m_fRightVal = 9;
			m_eCurState = STATE_FALL;
			m_tInfo.fY += m_fRightVal;

		}
		if (m_bIsColl)
		{
			m_fRightVal = 0;
			m_fJumpAcc = 0;
			m_fLeftVal = 0;
		}
	}
}

void CPlayer::Roll()
{
	m_eCurState = STATE_ROLL;
	if(m_wstrImageKey==L"Player_R")
		m_tInfo.fX += m_fSpeed*1.2;
	else if (m_wstrImageKey == L"Player_L")
		m_tInfo.fX -= m_fSpeed * 1.2;


}

void CPlayer::Jump()
{
	
	if (m_bIsJump)
	{
		if (!m_bDJump)
		{
			m_eCurState = STATE_JUMP;
			if (m_fLeftVal == 0)
				m_tInfo.fY -= 5;

			m_bIsColl = false;
			if (m_fLeftVal < 60)
			{
				m_fLeftVal = (m_fJumpForce)*m_fJumpAcc;
				m_fRightVal = m_fJumpForce*m_fJumpAcc*m_fJumpAcc*0.5;
				m_fJumpAcc += 0.15f;
			}

			m_tInfo.fY -= m_fLeftVal- m_fRightVal;

		}
	}

}
void CPlayer::WallJump()
{
	
	if (m_WallJump)
	{
		m_eCurState = STATE_WALLJUMP;
		m_iCount++;
		if(m_iDirection==0)
		m_tInfo.fX += cosf(30 / 180 * PI)*m_fAtkPower*0.5;
		else
			m_tInfo.fX -= cosf(30 / 180 * PI)*m_fAtkPower*0.5;
		m_tInfo.fY -=6;
		
		if (m_iCount % 20 == 0)
		{
			m_iCount = 0;
			m_bDJump = false;
			m_WallJump = false;
			m_bIsJump = false;
			m_eCurState = STATE_FALL;
		}
	}

}
void CPlayer::ScrollOffset()
{
	//�÷��̾ ȭ�鿡�� ���� ������ ����� �� ��ũ���� �����δ�.
	if (WinCX *0.75 <= m_WorldPos.x)
	{
		g_fScrollX += m_fSpeed;
	}
	if (WinCX *0.25 >= m_WorldPos.x)
	{
		g_fScrollX -= m_fSpeed;
	}
	if (CKeyManager::GetInstance()->KeyPressing(KEY_R))
	{
		g_fScrollX += sinf(GetTickCount()) * 5;
		g_fScrollY += sinf(GetTickCount()) * 5;

	}
	if (CKeyManager::GetInstance()->KeyUp(KEY_R))
	{
		g_fScrollY = 0;
	}
}


void CPlayer::Animate()
{
	DWORD dwCurTime = GetTickCount();

	if (m_tFrame.dwOldTime + m_tFrame.dwFrameSpeed/ g_fTime <= dwCurTime)
	{
		++m_tFrame.dwFrameStart;
		m_tFrame.dwOldTime = dwCurTime;
	}

	if (m_tFrame.dwFrameStart == m_tFrame.dwFrameCount)
		m_tFrame.dwFrameStart = 0;
	
	if (m_tAtkFrame.dwOldTime + m_tAtkFrame.dwFrameSpeed/ g_fTime <= dwCurTime)
	{
		++m_tAtkFrame.dwFrameStart;
		m_tAtkFrame.dwOldTime = dwCurTime;
	}

	if (m_tAtkFrame.dwFrameStart == m_tAtkFrame.dwFrameCount)
		m_tFrame.dwFrameStart = 0;

}

void CPlayer::ChangeState()
{
	// FSM (Finite State Machine, ���� ���� ���)
	// ������Ʈ�� �ѹ��� �ϳ��� ���¸� ���� �� �ִ�.
	//cout << "State="<< m_eCurState<< endl;
	 
	if (m_ePreState != m_eCurState)
	{
		switch (m_eCurState)
		{
		case STATE_IDLE:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 11;
			m_tFrame.dwFrameX =50;
			m_tFrame.dwFrameY = 0;
			m_tFrame.dwFrameSpeed = 100; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		case STATE_RUN:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 10;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 50;
			m_tFrame.dwFrameSpeed = 100; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		case STATE_JUMP:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 4;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 200;
			m_tFrame.dwFrameSpeed = 100; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		case STATE_FALL:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 4;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 250;
			m_tFrame.dwFrameSpeed = 100; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		case STATE_ATTACK:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 7;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 150;
			m_tFrame.dwFrameSpeed = 50; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			AniDirection();

			break;
		case STATE_ROLL:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 7;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 100;
			m_tFrame.dwFrameSpeed = 100; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		case STATE_WALLGRIP:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 1;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 500;
			m_tFrame.dwFrameSpeed = 100; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		case STATE_WALLJUMP:
			m_tFrame.dwFrameStart = 0;
			m_tFrame.dwFrameCount = 11;
			m_tFrame.dwFrameX = 50;
			m_tFrame.dwFrameY = 400;
			m_tFrame.dwFrameSpeed = 50; // 0.2�� ����
			m_tFrame.dwOldTime = GetTickCount();
			break;
		}

		m_ePreState = m_eCurState;
	}
}

void CPlayer::AniDirection()
{
	DWORD dwCurTime = GetTickCount();
	m_tAtkFrame.dwFrameCount = 5;
	m_tAtkFrame.dwFrameStart = 0;
	m_tAtkFrame.dwFrameX = 106;
	m_tAtkFrame.dwFrameSpeed = 50;
	m_tAtkFrame.dwOldTime = GetTickCount();
	//cout << m_fAngle << endl;
	if (m_fAngle >= 0)
		m_tAtkFrame.dwFrameY = 106*(int)((m_fAngle+7.5)/15);
	else if (m_fAngle < 0)
		m_tAtkFrame.dwFrameY = 106 * (int)(11-(-m_fAngle + 7.5) / 15)+1272;//10.5   -3      10.5  15  0 12

}

void CPlayer::BulletTime(HDC hdc)
{

	if (CKeyManager::GetInstance()->KeyPressing(KEY_SHIFT)&&m_fBulletGage-2>0)
	{
		if (m_iAlpha <= 150)
			m_iAlpha += 10;
		m_BlendFuntion.SourceConstantAlpha = m_iAlpha;
		AlphaBlend(hdc, 0, 0, WinCX, WinCY, CBmpManager::GetInstance()->GetMemDC(L"BulletTime"), 0, 0, 1280, 800, m_BlendFuntion);
		m_fBulletGage -= 2.f;
	}
	else
	{
		if (m_iAlpha>0)
			m_iAlpha -= 10;
		//cout << "bullettime" << endl;

		if (m_iAlpha < 0)
			m_iAlpha = 0;

		m_BlendFuntion.SourceConstantAlpha = m_iAlpha;
		if (m_iAlpha != 0)
			AlphaBlend(hdc, 0, 0, WinCX, WinCY, CBmpManager::GetInstance()->GetMemDC(L"BulletTime"), 0, 0, 1280, 800, m_BlendFuntion);
		
		if (m_fBulletGage < 100)
			m_fBulletGage += 1.0f;
		else if (m_fBulletGage > 100)
			m_fBulletGage = 100;
	}
}

void CPlayer::RenderUI(HDC hdc)
{//TODO:���� UI �߰��� ���͸�, �ð������� �߰���...
	HDC hMemDC = CBmpManager::GetInstance()->GetMemDC(L"HUDUI");
	NULL_CHECK(hMemDC);
	GdiTransparentBlt(hdc, 0, 0, 1280, 46, hMemDC, 0, 0, 640, 23, RGB(0, 0, 0));
	hMemDC = CBmpManager::GetInstance()->GetMemDC(L"HUDTimer");
	GdiTransparentBlt(hdc, WinCX*0.435, 0, 224, 38, hMemDC, 0, 0, 112, 19, RGB(0, 0, 0));
	hMemDC = CBmpManager::GetInstance()->GetMemDC(L"TimerGage");
	GdiTransparentBlt(hdc, WinCX*0.462, 4, 188.f-(m_fGameTimer/188.f), 22, hMemDC, 0, 0, 94, 11, RGB(0, 0, 0));
	hMemDC = CBmpManager::GetInstance()->GetMemDC(L"BatteryGage");
	GdiTransparentBlt(hdc, WinCX*0.025, 0, 154, 38, hMemDC, 0, 0, 77, 19, RGB(0, 0, 0)); 
	hMemDC = CBmpManager::GetInstance()->GetMemDC(L"Battery");
	int fGageVal =  (m_fBulletGage+2) / 10;

	GdiTransparentBlt(hdc, WinCX*0.0429, 8, 11*fGageVal, 20, hMemDC, 0, 0, 5*fGageVal, 10, SRCCOPY);




}
